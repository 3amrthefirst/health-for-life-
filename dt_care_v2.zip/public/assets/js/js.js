$(".side-toggle").click(function () {
  $(".sidebar").toggleClass("hide-sidebar");
  $(".right-content").toggleClass("right-content-0");
});



/*feather.icon()*/
