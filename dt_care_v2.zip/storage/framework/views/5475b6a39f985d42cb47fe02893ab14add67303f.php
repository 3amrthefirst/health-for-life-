<?php $__env->startSection('content'); ?>
<?php echo $__env->make('admin.layout.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<div class="right-content">
    <header class="header">
        <div class="title-control">
            <h1 class="page-title"><?php echo e(__('label.company')); ?></h1>
        </div>
        <div class="head-control">
            <?php echo $__env->make('admin.layout.header_setting', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>
    </header>
    <div class="row top-20 p-0 mr-3 ml-3">
        <div class="col-md-12">
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="<?php echo e(route('admin.dashboard')); ?>"><?php echo e(__('label.dashboard')); ?></a></li>
                <li class="breadcrumb-item active"><a href="<?php echo e(route('company.index')); ?>"><?php echo e(__('label.company')); ?></a></li>
                <li class="breadcrumb-item active"><a href=""><?php echo e(__('label.add_company')); ?></a></li>
            </ol>
        </div>  
    </div>

    <div class="body-content">
        <div class="card custom-border-card mt-3">
            <h5 class="card-header">Add Company </h5>
                <div class="card-body">
                    <form class="cmxform" autocomplete="off" id="save_add_company" enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>

                        <div class="form-group">
                            <label><?php echo e(__('label.name')); ?></label>
                                <input type="text" class="form-control col-8" name="name" placeholder="Enter Your Company Name">
                        </div>

                        <div class="border-top pt-3 text-right">
                            <button class="btn btn-default mw-120" type="button" onclick="save_add_company()"><?php echo e(__('label.save')); ?></button>
                            <a class="btn btn-default btn-dark mw-120" style="background: black;" type="button" href="<?php echo e(route('company.index')); ?>"><?php echo e(__('label.cancel')); ?></a>
                        </div>
                    </form>
                </div>
        </div>
    </div>

</div>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('pagescript'); ?>
<script type="text/javascript">
    function save_add_company(){
        var formData = new FormData($("#save_add_company")[0]);
            $.ajax({
                type:'POST',
                url:'<?php echo e(route("company.store")); ?>',
                data:formData,
                cache:false,
                contentType: false,
                processData: false,
                success: function (resp) {
                   
                get_responce_message(resp, 'save_add_company', '<?php echo e(route("company.index")); ?>');
                },
                error: function(XMLHttpRequest, textStatus, errorThrown) {
                    $("#dvloader").hide();
                    toastr.error(errorThrown.msg,'failed');         
                }
            });
    }
</script> 
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout.page-app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /opt/lampp/htdocs/envato/app/DTCare/resources/views/admin/company/add.blade.php ENDPATH**/ ?>