
<?php $__env->startSection('content'); ?>
<?php echo $__env->make('admin.layout.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<div class="right-content">
  <header class="header">
    <div class="title-control">
      <h1 class="page-title"><?php echo e(__('label.Page')); ?></h1>
    </div>
    <div class="head-control">
      <?php echo $__env->make('admin.layout.header_setting', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </div>
  </header>

  <div class="body-content">
    
    <!-- mobile title -->
    <h1 class="page-title-sm"> <?php echo e(__('label.Page')); ?> </h1>

    <div class="border-bottom row mb-3">
      <div class="col-sm-12">
        <ol class="breadcrumb">
          <li class="breadcrumb-item"><a href="<?php echo e(route('admin.dashboard')); ?>"><?php echo e(__('label.Dashboard')); ?></a>
          </li>
          <li class="breadcrumb-item active" aria-current="page">
            <?php echo e(__('label.Page')); ?>

          </li>
        </ol>
      </div>
    </div>

    <div class="table-responsive table">
      <table class="table table-striped text-center table-bordered" id="datatable">
        <thead>
          <tr style="background: #F9FAFF;">
            <th> <?php echo e(__('label.title')); ?> </th>
            <th> <?php echo e(__('label.action')); ?> </th>
          </tr>
        </thead>
        <tbody>

        </tbody>
      </table>
    </div>
  </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('pagescript'); ?>
  <script>
    $(document).ready(function() {
      $(function () {
        var table = $('#datatable').DataTable({
          "responsive": true,
          "autoWidth": false,
          language: {
            paginate: {
              previous: "<img src='<?php echo e(asset('assets/imgs/left-arrow.png')); ?>' >",
              next: "<img src='<?php echo e(asset('assets/imgs/left-arrow.png')); ?>' style='transform: rotate(180deg)'>"
            }
          },
          processing: true,
          serverSide: false,
          ajax: "<?php echo e(route('page.store')); ?>",
          columns: [
            {data: 'title', name:'title', orderable: false, searchable: false},
            {data: 'action', name: 'action', orderable: false, searchable: false},
          ],
        });
      });
    });
  </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout.page-app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u451299909/domains/divinetechs.in/public_html/demo/apps/dtcare/resources/views/admin/page/index.blade.php ENDPATH**/ ?>