<?php $__env->startSection('content'); ?>
<?php echo $__env->make('admin.layout.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<div class="right-content">
    <header class="header">
        <div class="title-control">
            <h1 class="page-title"><?php echo e(__('label.Medicine')); ?></h1>
        </div>
        <div class="head-control">
            <?php echo $__env->make('admin.layout.header_setting', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>
    </header>
    <div class="row top-20 ml-3 mr-3">
        <div class="col-md-12">
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="<?php echo e(route('admin.dashboard')); ?>"><?php echo e(__('label.dashboard')); ?></a></li>
                <li class="breadcrumb-item active"><a href="<?php echo e(route('medicine.index')); ?>"><?php echo e(__('label.Medicine')); ?></a></li>
                <li class="breadcrumb-item active"><a href=""><?php echo e(__('label.Edit_Medicine')); ?></a></li>
            </ol>
        </div>
    </div>

    <div class="body-content">
        <div class="card custom-border-card mt-3">
            <h5 class="card-header"><?php echo e(__('label.Edit_Medicine')); ?></h5>
            <div class="card-body">
                <form class="cmxform" autocomplete="off" id="edit_medicine" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>

                    <input type="hidden" name="id" value="<?php if($data): ?><?php echo e($data->id); ?><?php endif; ?>">
                   
                    <div class="form-group row">
                        <div class="col-md-12">
                            <label><?php echo e(__('label.name')); ?></label>
                            <input type="text" class="form-control" name="name" value="<?php if($data): ?><?php echo e($data->name); ?><?php endif; ?>">
                        </div>
                    </div>
                    <div class="form-group row">
                        <div class="col-md-6">
                            <label><?php echo e(__('label.Form')); ?></label>
                            <select class="form-control required" name="form">
                                <option value=""><?php echo e(__('label.Select Form')); ?></option>
                                <option value="Tablet" <?php echo e($data->form == "Tablet"  ? 'selected' : ''); ?>><?php echo e(__('label.Tablet')); ?></option>
                                <option value="Liquid" <?php echo e($data->form == "Liquid"  ? 'selected' : ''); ?>><?php echo e(__('label.Liquid')); ?></option>
                                <option value="Capsule" <?php echo e($data->form == "Capsule"  ? 'selected' : ''); ?>><?php echo e(__('label.Capsule')); ?></option>
                                <option value="Syrup" <?php echo e($data->form == "Syrup"  ? 'selected' : ''); ?>><?php echo e(__('label.Syrup')); ?></option>
                            </select>
                        </div>
                        <div class="col-md-6">
                            <label><?php echo e(__('label.Power')); ?></label>
                            <input type="text" class="form-control" name="power" value="<?php if($data): ?><?php echo e($data->power); ?><?php endif; ?>" placeholder="Enter Medicine Power">
                        </div>
                    </div>  
    
                    <div class="border-top pt-3 text-right">
                        <button class="btn btn-default mw-120" type="button" onclick="edit_medicine()"><?php echo e(__('label.save')); ?></button>
                        <a class="btn btn-default btn-dark mw-120" style="background: black;" type="button" href="<?php echo e(route('medicine.index')); ?>"><?php echo e(__('label.cancel')); ?></a>
                        <input type="hidden" name="_method" value="PATCH">
                    </div>   
                  
                </form>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('pagescript'); ?>
<script type="text/javascript">
    function edit_medicine(){

        var formData = new FormData($("#edit_medicine")[0]);
        $.ajax({
            type:'POST',
            url:'<?php echo e(route("medicine.update" ,[$data->id])); ?>',
            data:formData,
            cache:false,
            contentType: false,
            processData: false,
            success: function (resp) {
            get_responce_message(resp, 'edit_medicine', '<?php echo e(route("medicine.index")); ?>');
            },
            error: function(XMLHttpRequest, textStatus, errorThrown) {
                $("#dvloader").hide();
                toastr.error(errorThrown.msg,'failed');         
            }
        });
    }
</script>	
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout.page-app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u451299909/domains/divinetechs.in/public_html/demo/apps/dtcare/resources/views/admin/medicine/edit.blade.php ENDPATH**/ ?>