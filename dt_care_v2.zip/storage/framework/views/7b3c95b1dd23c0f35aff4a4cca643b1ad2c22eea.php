<!DOCTYPE html>
<html>
    <head>
        <title>How to Generate QR Code in Laravel 8? - raviyatechnical</title>
    </head>
    <body>
        <div class="visible-print text-center">
            <h1>Laravel 8 - QR Code Generator Example</h1>
            <?php echo QrCode::size(250)->generate('raviyatechnical', storage_path('app/public/patients_qrcode/code.png')); ?>

            <p>example by raviyatechnical.</p>
        </div>
    </body>
</html><?php /**PATH /opt/lampp/htdocs/envato/app/DTCare/resources/views/qrCode.blade.php ENDPATH**/ ?>