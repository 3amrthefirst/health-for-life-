<!-- start:Left Menu -->
<div class="sidebar">
    <div class="side-head">
      <?php if(setting_app_name() == ""): ?>
      <a href="<?php echo e(route('admin.dashboard')); ?>">
        <img src="<?php echo e(asset('/assets/imgs/DT1.png')); ?>" class="side-logo" />
      </a>
      <?php else: ?>
      <a href="<?php echo e(route('admin.dashboard')); ?>" style="color:#4e45b8;">
        <h3><?php echo e(setting_app_name()); ?></h3>
      </a>
      <?php endif; ?>
        <button class="btn side-toggle">
            <span></span>
            <span></span>
            <span></span>
        </button>
    </div>

    <ul class="side-menu">
      
      <li class="<?php echo e((request()->routeIs('admin.dashboard*')) ? 'active' : ''); ?>"><a href="<?php echo e(route('admin.dashboard')); ?>">
        <img src="<?php echo e(asset('/assets/imgs/dashboard.png')); ?>" class="menu-icon" />
        <span> <?php echo e(__('label.dashboard')); ?> </span>
        </a>
      </li>

      <li class="<?php echo e((request()->routeIs('appointment*')) ? 'active' : ''); ?>"><a href="<?php echo e(route('appointment.index')); ?>">
        <img src="<?php echo e(asset('/assets/imgs/watch.png')); ?>" class="menu-icon" />
        <span> <?php echo e(__('label.appointment')); ?> </span>
        </a>
      </li>

      <li class="<?php echo e((request()->routeIs('doctor*')) ? 'active' : ''); ?>"><a href="<?php echo e(route('doctor.index')); ?>">
        <img src="<?php echo e(asset('/assets/imgs/doctor.png')); ?>" class="menu-icon" />
        <span> <?php echo e(__('label.doctor')); ?> </span>
        </a>
      </li>

      <li class=" <?php echo e((request()->routeIs('patient*')) ? 'active' : ''); ?> "><a href="<?php echo e(route('patient.index')); ?>">
        <img src="<?php echo e(asset('/assets/imgs/user.png')); ?>" class="menu-icon" />
        <span> <?php echo e(__('label.patient')); ?> </span>
        </a>
      </li>
      
      <li class="<?php echo e((request()->routeIs('specialties*')) ? 'active' : ''); ?>  "><a href="<?php echo e(route('specialties.index')); ?> ">
        <img src="<?php echo e(asset('/assets/imgs/dashboard.png')); ?>" class="menu-icon" />
        <span> <?php echo e(__('label.specialitie')); ?> </span>
        </a>
      </li>

      <li class="<?php echo e((request()->routeIs('medicine*')) ? 'active' : ''); ?>  "><a href="<?php echo e(route('medicine.index')); ?> ">
        <img src="<?php echo e(asset('/assets/imgs/medicine.png')); ?>" class="menu-icon" />
        <span> <?php echo e(__('label.Medicine')); ?> </span>
        </a>
      </li>

      <li class="<?php echo e((request()->routeIs('review*')) ? 'active' : ''); ?> "><a href="<?php echo e(route('review.index')); ?>">
        <img src="<?php echo e(asset('/assets/imgs/comment.png')); ?>" class="menu-icon" />
        <span> <?php echo e(__('label.review')); ?> </span>
        </a>
      </li>

      <li class="<?php echo e((request()->routeIs('company*')) ? 'active' : ''); ?>"><a href="<?php echo e(route('company.index')); ?>">
        <img src="<?php echo e(asset('/assets/imgs/company.png')); ?>" class="menu-icon"  alt=""/>
        <span> <?php echo e(__('label.company')); ?> </span>
        </a>
      </li>

      <li class="<?php echo e(request()->is('admin/page*') ? 'active' : ''); ?>">
        <a href="<?php echo e(route('page.index')); ?>">
          <img class="menu-icon" src="<?php echo e(asset('assets/imgs/pages.png')); ?>" alt="" />
          <span><?php echo e(__('label.Page')); ?></span>
        </a>
      </li>

      <!-- <li class="<?php echo e((request()->routeIs('Notification*')) ? 'active' : ''); ?> "><a href="<?php echo e(route('Notification')); ?>">
        <img src="<?php echo e(asset('/assets/imgs/message.png')); ?>" class="menu-icon" alt="" />
        <span> <?php echo e(__('label.notification')); ?> </span>
        </a>
      </li> -->

      <li class="<?php echo e((request()->routeIs('Setting*')) ? 'active' : ''); ?> <?php echo e((request()->routeIs('EmailSetting')) ? 'active' : ''); ?> "><a href="<?php echo e(route('Setting')); ?>">
        <img src="<?php echo e(asset('/assets/imgs/settings.png')); ?>" class="menu-icon" alt="" />
        <span> <?php echo e(__('label.setting')); ?> </span>
        </a>
      </li>


      <li class=" "><a href="<?php echo e(route('Logout')); ?>">
        <img src="<?php echo e(asset('/assets/imgs/logout.png')); ?>" class="menu-icon" />
          <span> <?php echo e(__('label.logout')); ?> </span>
        </a>
      </li>

    </ul>
</div>
<!-- end: Left Menu --><?php /**PATH D:\xampp\htdocs\envato\app\dt_care_laravel\resources\views/admin/layout/sidebar.blade.php ENDPATH**/ ?>