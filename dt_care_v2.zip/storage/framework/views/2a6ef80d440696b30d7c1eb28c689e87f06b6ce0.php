<?php $__env->startSection('content'); ?>
<?php echo $__env->make('admin.layout.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<div class="right-content">
  <header class="header">
      <div class="title-control">
          <h1 class="page-title">Appointment</h1>
      </div>
      <div class="head-control">
          <?php echo $__env->make('admin.layout.header_setting', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
      </div>
  </header>

  <div class="body-content">
    <!-- mobile title -->
    <h1 class="page-title-sm">Appointment</h1>

    <div class="border-bottom row mb-3">
        <div class="col-sm-10">
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="<?php echo e(route('admin.dashboard')); ?>"><?php echo e(__('label.dashboard')); ?></a></li>
                <li class="breadcrumb-item">Appointment</li>
            </ol>
        </div>
        <div class="col-md-2">
            <div class="d-flex align-items-center justify-content-end">
                <a href="<?php echo e(route('appointment.index')); ?>" class="btn btn-default mw-120">Appointment</a>
            </div>
        </div>
    </div>

    <div class="card custom-border-card">
        <table class="table table-striped table-hover table-bordered w-75 text-center" style="margin-left:auto; margin-right:auto">
            <thead>
                <tr class="table-info">
                    <th colspan="2">Appointment Details</th>
                </tr>
            </thead>
            <tbody >
                <tr>
                    <td> Doctor Name </td>
                    <td><?php echo e($data->doctor->first_name); ?> <?php echo e($data->doctor->last_name); ?></td>
                </tr>
                <tr>
                    <td> Patient Name </td>
                    <td><?php echo e($data->patient->fullname ?? "-"); ?></td>
                </tr>
                <tr>
                    <td> Date </td>
                    <td><?php echo e($data->date ?? "-"); ?></td>
                </tr>
                <tr>
                    <td> Start Time</td>
                    <td><?php echo e($data->startTime); ?></td>
                </tr>
                <tr>
                    <td> End Time </td>
                    <td><?php echo e($data->endTime); ?></td>
                </tr>
                <tr>
                    <td> Description </td>
                    <td><?php echo e($data->description); ?></td>
                </tr>      
                <tr>
                    <td> Symptoms </td>
                    <td>
                        <?php if($data->symptoms): ?>
                            <?php echo e($data->symptoms); ?>

                        <?php else: ?>
                            -
                        <?php endif; ?>  
                    </td>
                </tr>      
                <tr>
                    <td> Doctor Symptoms </td>
                    <td>
                        <?php if($data->doctor_symptoms): ?>
                            <?php echo e($data->doctor_symptoms); ?>

                        <?php else: ?>
                            -
                        <?php endif; ?>  
                    </td>
                </tr>
                <tr>
                    <td> Doctor Diagnosis </td>
                    <td>
                        <?php if($data->doctor_diagnosis): ?>
                            <?php echo e($data->doctor_diagnosis); ?>

                        <?php else: ?>
                            -
                        <?php endif; ?>    
                    </td>
                </tr>
                <tr>
                    <td> Medicines Taken </td>
                    <td>
                        <?php if($data->medicines_taken): ?>
                            <?php echo e($data->medicines_taken); ?>

                        <?php else: ?>
                            -
                        <?php endif; ?>
                    </td>
                </tr>
                <tr>
                    <td> Insurance Details </td>
                    <td>
                        <?php if($data->insurance_details): ?>
                            <?php echo e($data->insurance_details); ?>

                        <?php else: ?>
                            -
                        <?php endif; ?>
                    </td>
                </tr>
                <tr>
                    <td> Mobile Number </td>
                    <td>
                        <?php if($data->mobile_number): ?>
                            <?php echo e($data->mobile_number); ?>

                        <?php else: ?>
                            -
                        <?php endif; ?>
                    </td>
                </tr>       
            </tbody>
        </table>
    </div>

  </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout.page-app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /opt/lampp/htdocs/envato/app/DTCare/resources/views/admin/appointment/details.blade.php ENDPATH**/ ?>