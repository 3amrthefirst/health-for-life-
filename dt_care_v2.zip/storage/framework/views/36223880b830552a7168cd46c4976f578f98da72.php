<?php $__env->startSection('content'); ?>
<?php echo $__env->make('admin.layout.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<div class="right-content">
    <header class="header">
        <div class="title-control">
            <h1 class="page-title"><?php echo e(__('label.doctor')); ?></h1>
        </div>
        <div class="head-control">
            <?php echo $__env->make('admin.layout.header_setting', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>
    </header>

    <div class="row top-20 ml-2 mr-2">
        <div class="col-md-12">
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="<?php echo e(route('admin.dashboard')); ?>"><?php echo e(__('label.dashboard')); ?></a></li>
                <li class="breadcrumb-item active"><a href="<?php echo e(route('doctor.index')); ?>"><?php echo e(__('label.doctor')); ?></a></li>
                <li class="breadcrumb-item active"><a href=""><?php echo e(__('label.add_doctor')); ?></a></li>
            </ol>
        </div>
     
    </div>

    <div class="body-content">
        <div class="card custom-border-card mt-3">
            <h5 class="card-header"><?php echo e(__('label.edit_doctor')); ?></h5>
            <div class="card-body">
                <form class="cmxform" autocomplete="off" id="save_doctor" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    <input type="hidden" name="id" value="<?php if($data): ?><?php echo e($data->id); ?><?php endif; ?>">
                    <div class="col-md-12">
                        <div class="form-group row">
                            <div class="col-md-6">
                                <label><?php echo e(__('label.first_name')); ?></label>
                                <input type="text" class="form-control" name="first_name" value="<?php if($data): ?><?php echo e($data->first_name); ?><?php endif; ?>" placeholder="Enter First Name">
                            </div>
                            <div class="col-md-6">
                                <label><?php echo e(__('label.last_name')); ?></label>
                                <input type="text" class="form-control" name="last_name" value="<?php if($data): ?><?php echo e($data->last_name); ?><?php endif; ?>" placeholder="Enter Last Name">
                            </div>
                        </div>
                    </div>   
                    <div class="col-md-12">
                        <div class="form-group row">
                            <div class="col-md-6">
                                <label><?php echo e(__('label.email')); ?></label>
                                <input type="email" class="form-control" name="email" value="<?php if($data): ?><?php echo e($data->email); ?><?php endif; ?>" placeholder="Enter Email">
                            </div>
                            <div class="col-md-6">
                                <label><?php echo e(__('label.password')); ?></label>
                                <input type="password" class="form-control" name="password" value="<?php if($data): ?><?php echo e($data->password); ?><?php endif; ?>" placeholder="Enter Password">
                            </div>
                        </div>
                    </div> 
                    <div class="col-md-12">
                        <div class="form-group row">
                            <div class="col-md-6">
                                <label><?php echo e(__('label.mobile_number')); ?></label>
                                <input type="text" class="form-control" name="mobile_number" value="<?php if($data): ?><?php echo e($data->mobile_number); ?><?php endif; ?>" placeholder="Enter Mobile Number">
                            </div>
                            <div class="col-md-6">
                                <label for="specialties_id"><?php echo e(__('label.speciatiles')); ?></label>
                                <select class="form-control" name="specialties_id" value="<?php if($data): ?><?php echo e($data->specialties_id); ?><?php endif; ?>">
                                    <option value="">Select Speciatiles</option>
                                    <?php $__currentLoopData = $result; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($item['id']); ?>" <?php echo e($item->id == $data->specialties_id ? 'selected' : ''); ?>><?php echo e($item['name']); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-12">
                        <div class="form-group row">
                            <!-- <div class="col-md-6">
                                <label><?php echo e(__('label.working_time')); ?></label>
                                <input type="text" class="form-control" name="working_time" value="<?php if($data): ?><?php echo e($data->working_time); ?><?php endif; ?>">
                            </div> -->
                            <div class="col-md-12">
                                <label><?php echo e(__('label.address')); ?></label>
                                <input type="text" class="form-control" name="address" value="<?php if($data): ?><?php echo e($data->address); ?><?php endif; ?>" placeholder="Enter Address">
                            </div>
                        </div>
                    </div> 
                    <div class="col-md-12">
                        <div class="form-group row">
                            <div class="col-md-6">
                                <label for="about_us"><?php echo e(__('label.about_us')); ?></label>
                                <textarea class="form-control" name="about_us" id="about_us" rows="3" placeholder="Describe yourself here..."><?php echo e($data->about_us); ?></textarea>
                            </div>
                            <div class="col-md-6">
                                <label for="services"><?php echo e(__('label.service')); ?></label>
                                <textarea class="form-control" name="services" id="services" rows="3" placeholder="Describe Your Service..."><?php echo e($data->services); ?></textarea>
                            </div>
                        </div>
                    </div> 
                    <div class="col-md-12">
                        <div class="form-group row">
                            <div class="col-md-6">
                                <label for="health_care"><?php echo e(__('label.health_Care')); ?></label>
                                <textarea class="form-control" name="health_care" id="health_care" placeholder="Enter Health Care..." rows="3"> <?php echo e($data->health_care); ?></textarea>
                            </div>
                            <div class="col-md-6">
                                <label>Instagram Url</label>
                                <input type="text" class="form-control" name="instagram_url" value="<?php if($data): ?><?php echo e($data->instagram_url); ?><?php endif; ?>" placeholder="Enter Url">
                            </div>
                        </div>
                    </div> 
                    <div class="col-md-12">
                        <div class="form-group row">
                            <div class="col-md-6">
                                <label><?php echo e(__('label.facebook_url')); ?></label>
                                <input type="text" class="form-control" name="facebook_url" value="<?php if($data): ?><?php echo e($data->facebook_url); ?><?php endif; ?>" placeholder="Enter Url">
                            </div>
                            <div class="col-md-6">
                                <label>Twitter Url</label>
                                <input type="text" class="form-control" name="twitter_url" value="<?php if($data): ?><?php echo e($data->twitter_url); ?><?php endif; ?>" placeholder="Enter Url">
                            </div>
                        </div>
                    </div> 
                    <div class="col-sm-12">
                        <div class="form-group">
                            <label class="mb-1"><?php echo e(__('label.image')); ?></label>
                            <input type="file" id="fileupload" onchange="readURL(this,'idLogo')" class="<?php if($data): ?><?php echo e($data->profile_img); ?><?php endif; ?>"  hidden name="profile_img" />
                            <input type="hidden" name="old_image" value="<?php if($data): ?><?php echo e($data->profile_img); ?><?php endif; ?>">
                            <label for="fileupload" class="form-control file-control">
                                <img src="<?php echo e(asset('/assets/imgs/file-upload.png')); ?>" alt="" />
                                <span>Select Image </span>
                            </label>
                            <div class="thumbnail-img" id="idMainLogo">
                                <?php if($data && $data->profile_img): ?>
                                <?php $app = (image_path('doctor')).'/'.$data->profile_img ;?>
                                <img id="idLogo" src="<?php echo e($app); ?>" />
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                    <div class="border-top pt-3 text-right">
                        <button class="btn btn-default mw-120" type="button" onclick="save_doctor()"><?php echo e(__('label.save')); ?></button>
                        <a class="btn btn-default btn-dark mw-120" style="background: black;" type="button" href="<?php echo e(route('doctor.index')); ?>"><?php echo e(__('label.cancel')); ?></a>
                        <input type="hidden" name="_method" value="PATCH">
                    </div>   
                </form>           
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('pagescript'); ?>
    <script type="text/javascript">
        $(document).ready(function() {
            $('#fileupload').change(function(event) {
                if (event.target.files && event.target.files[0]) {
                    var html = '<button class="close" type="button"> <span aria-hidden="true">&times;</span></button>';
                    html = '<img src="" id="idLogo"/>';
                    $('#idMainLogo').html(html)
                    var reader = new FileReader();
                    reader.onload = function() {
                        var output = document.getElementById('idLogo');
                        output.src = reader.result;
                    };
                    reader.readAsDataURL(event.target.files[0]);
                    $(this).valid()
                }
            });
        });

        function save_doctor(){
            var formData = new FormData($("#save_doctor")[0]);
            $.ajax({
                type:'POST',
                url:'<?php echo e(route("doctor.update" ,[$data->id])); ?>',
                data:formData,
                cache:false,
                contentType: false,
                processData: false,
                success: function (resp) {
                get_responce_message(resp, 'save_doctor', '<?php echo e(route("doctor.index")); ?>');
                },
                error: function(XMLHttpRequest, textStatus, errorThrown) {
                    $("#dvloader").hide();
                    toastr.error(errorThrown.msg,'failed');         
                }
            });
        }
    </script>	
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout.page-app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /opt/lampp/htdocs/envato/app/DTCare/resources/views/admin/doctor/edit.blade.php ENDPATH**/ ?>