<?php $__env->startSection('content'); ?>
<?php echo $__env->make('admin.layout.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<div class="right-content">
    <header class="header">
        <div class="title-control">
            <h1 class="page-title"><?php echo e(__('label.commnet')); ?></h1>
        </div>
        <div class="head-control">
            <?php echo $__env->make('admin.layout.header_setting', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>
    </header>
    
    <div class="row top-20 ml-2 mr-2">
        <div class="col-md-12">
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="<?php echo e(route('admin.dashboard')); ?>"><?php echo e(__('label.dashboard')); ?></a></li>
                <li class="breadcrumb-item active"><a href="<?php echo e(route('review.index')); ?>"><?php echo e(__('label.commnet')); ?></a></li>
            </ol>
        </div>
    </div>

    <div class="col-md-12 top-20 padding-0">
            <div class="col-md-12">
                <div class="panel">
                    <div class="panel-body">
                        <div class="responsive-table">
                            <table class="table table-striped table-bordered" id="patient">
                                <thead style="background: #F9FAFF;">
                                    <tr>
                                        <th><?php echo e(__('label.id')); ?></th>
                                        <th><?php echo e(__('label.doctor_name')); ?></th>
                                        <th><?php echo e(__('label.patient_name')); ?></th>
                                        <th><?php echo e(__('label.commnet')); ?></th>
                                        <th><?php echo e(__('label.date')); ?></th>
                                    </tr>
                                </thead>
                                <tbody>

                                </tbody>
                            </table>
                        </div>
                    </div> 
                </div>
	        </div>
        </div>
    </div>
</div>    
<?php $__env->stopSection(); ?>

<?php $__env->startSection('pagescript'); ?>
    <script type="text/javascript">
        $(function () {
            var table = $('#patient').DataTable({
                "responsive": true,
                "autoWidth": false,
                lengthMenu: [ [10, 25, 50, -1], [10, 25, 50, 'All'] ],
                processing: true,
                serverSide: true,
                language: {
                    paginate: {
                    previous: " <img src='<?php echo e(url('assets/imgs/left-arrow.png')); ?>'>",
                    next: " <img src='<?php echo e(url('assets/imgs/left-arrow.png')); ?>' style='transform:rotate(180deg)'>"
                    }
                },
                order: [[0, "DESC"]],
                ajax:"<?php echo e(route('review.index')); ?>",
                columns: [
                
                {data: 'id',name: 'id'},
                {data: 'doctor_id',name: 'doctor_id'},
                {data: 'patient_id',name: 'fullname'},
                {data: 'comment',name: 'comment'},
                {data: 'created_at',name: 'created_at'},
                
                
                ]
            });
        });
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout.page-app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\envato\app\dt_care_laravel\resources\views/admin/review/index.blade.php ENDPATH**/ ?>