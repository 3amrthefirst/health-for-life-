<?php $__env->startSection('content'); ?>
<?php echo $__env->make('admin.layout.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<div class="right-content">
    
    <header class="header">
        <div class="title-control">
            <h1 class="page-title"><?php echo e(__('label.dashboard')); ?></h1>
        </div>
        <div class="head-control">
            <?php echo $__env->make('admin.layout.header_setting', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>
    </header>

    <div class="body-content">
        <div class="row counter-row">
            <div class="col-6 col-sm-4 col-md col-lg-4 col-xl">
                <div class="db-color-card">
                    <img src="<?php echo e(asset('/assets/imgs/appointment-time.png')); ?>" class="card-icon" />
                        <h2 class="counter"><?php echo e($result['appointment']); ?>

                            <span><?php echo e(__('label.appointment')); ?></span>
                        </h2>
                </div>
            </div>

            <div class="col-6 col-sm-4 col-md col-lg-4 col-xl">
                <div class="db-color-card cate-card">
                    <img src="<?php echo e(asset('/assets/imgs/medical-doctor.png')); ?>" class="card-icon" />
                        <h2 class="counter"><?php echo e($result['doctor']); ?>

                            <span><?php echo e(__('label.doctor')); ?></span>
                        </h2>
                </div>
            </div>

            <div class="col-6 col-sm-4 col-md col-lg-4 col-xl">
                <div class="db-color-card user-card">
                    <img src="<?php echo e(asset('/assets/imgs/user-brown.png')); ?>" class="card-icon" />
                        <h2 class="counter"><?php echo e($result['patient']); ?>

                            <span><?php echo e(__('label.patient')); ?></span>
                        </h2>
                </div>
            </div>

            <div class="col-6 col-sm-4 col-md col-lg-4 col-xl">
                <div class="db-color-card artist-card">
                    <img src="<?php echo e(asset('/assets/imgs/doctors-bag.png')); ?>" class="card-icon" />
                        <h2 class="counter"><?php echo e($result['specialtie']); ?>

                            <span><?php echo e(__('label.Specialities')); ?></span>
                        </h2>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout.page-app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u451299909/domains/divinetechs.in/public_html/demo/apps/dtcare/resources/views/admin/dashboard.blade.php ENDPATH**/ ?>