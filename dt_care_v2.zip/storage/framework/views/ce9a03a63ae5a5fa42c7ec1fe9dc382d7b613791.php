<?php $__env->startSection('content'); ?>
<?php echo $__env->make('admin.layout.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<div class="right-content">
  <header class="header">
      <div class="title-control">
          <h1 class="page-title">Appointment</h1>
      </div>
      <div class="head-control">
          <?php echo $__env->make('admin.layout.header_setting', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
      </div>
  </header>

  <div class="body-content">
    <!-- mobile title -->
    <h1 class="page-title-sm">Appointment</h1>

    <div class="border-bottom row mb-3">
        <div class="col-sm-12">
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="<?php echo e(route('admin.dashboard')); ?>"><?php echo e(__('label.dashboard')); ?></a></li>
                <li class="breadcrumb-item">Appointment</li>
            </ol>
        </div>
    </div>

    <!-- Serach Dropdown -->
    <div class="">
      <form class="" action="<?php echo e(route('appointment.index')); ?>" method="GET">
        <div class="form-row">
          <div class="col-md-1 d-flex align-items-center">
            <label for="type"><?php echo e(__('label.SEARCH')); ?> :</label>
          </div>
          <div class="col-md-2">
            <div class="form-group">
              <select class="form-control" id="doctor" name="doctor">
              <option value="all">All Doctor</option>
                <?php for($i = 0; $i < count($doctor); $i++): ?>
                  <option value="<?php echo e($doctor[$i]['id']); ?>" <?php if(isset($_GET['doctor'])): ?><?php echo e($_GET['doctor'] == $doctor[$i]['id'] ? 'selected' : ''); ?> <?php endif; ?>> <?php echo e($doctor[$i]['first_name']); ?>  <?php echo e($doctor[$i]['last_name']); ?> </option>
                <?php endfor; ?>
              </select>
            </div>
          </div>
          <div class="col-sm-2 ml-4">
            <button class="btn btn-default" type="submit"> <?php echo e(__('label.SEARCH')); ?> </button>
          </div>
        </div>
      </form>
    </div>

    <div class="row">
      <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <div class="col-12 col-sm-6 col-md-4 col-xl-3">
        <div class="card video-card">
          <div class="position-relative">
            <img class="card-img-top" src="<?php echo e(asset('assets/imgs/appoinment.jpg')); ?>" alt="">
          </div>
          <div class="card-body">
            <h5 class="card-title mr-5" style="font-size: 14px;">Doctor Name : <?php if(isset($value->doctor)){ ?> <?php echo e($value->doctor->first_name); ?> <?php echo e($value->doctor->last_name); ?> <?php } else {echo "-";}?> </h5>
            <h5 class="card-title mr-5"  style="font-size: 14px;">Patient Name :  <?php if(isset($value->patient)){ ?> <?php echo e($value->patient->fullname); ?> <?php } else {echo "-";}?></h5>
            <div class="dropdown dropright">
              <a href="#" class="btn head-btn" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                <img src="<?php echo e(asset('assets/imgs/dot.png')); ?>" class="dot-icon" />
              </a>

              <div class="dropdown-menu" aria-labelledby="dropdownMenuLink">
                <a class="dropdown-item" href="<?php echo e(route('appointment.show', [$value->id] )); ?>">
                  <img src="<?php echo e(asset('assets/imgs/view.png')); ?>" class="dot-icon" />
                  Details
                </a>
              </div>
            </div>
            <div class="card-details">
              <div class="tag">
                <?php if($value->status == 1): ?>
                  <button type="button" style="background:#0dceec; font-size:14px; font-weight:bold; letter-spacing:0.1px; border: none; color: white; padding: 5px 15px; outline: none;">Pending</button>
                <?php elseif($value->status == 2): ?>
                  <button type="button" style="background:#3BB143; font-size:14px; font-weight:bold; letter-spacing:0.1px; border: none; color: white; padding: 5px 15px; outline: none;">Approved</button>
                <?php elseif($value->status == 3): ?>
                  <button type="button" style="background:#FF9700; font-size:14px; font-weight:bold; letter-spacing:0.1px; border: none; color: white; padding: 5px 15px; outline: none;">Rejected</button>
                <?php elseif($value->status == 4): ?>
                  <button type="button" style="background:#FF0000; font-size:14px; font-weight:bold; letter-spacing:0.1px; border: none; color: white; padding: 5px 15px; outline: none;">Absent</button>
                <?php elseif($value->status == 5): ?>
                  <button type="button" style="background:#003300; font-size:14px; font-weight:bold; border: none; color: white; padding: 4px 20px; outline: none;">Completed</button>
                <?php endif; ?>
              </div>
            </div>
          </div>
        </div>
      </div>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
    <!-- Pagination -->
    <div class="d-flex justify-content-between align-items-center">
      <div> Showing <?php echo e($data->firstItem()); ?> to <?php echo e($data->lastItem()); ?> of total <?php echo e($data->total()); ?> entries </div>
      <div class="pb-5"> <?php echo e($data->links('pagination::bootstrap-4')); ?> </div>
    </div>

  </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout.page-app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\envato\app\dt_care_laravel\resources\views/admin/appointment/index.blade.php ENDPATH**/ ?>