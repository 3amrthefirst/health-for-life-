<?php $__env->startSection('content'); ?>
<?php echo $__env->make('admin.layout.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<div class="right-content">
    <header class="header">
        <div class="title-control">
            <h1 class="page-title"><?php echo e(__('label.patients')); ?></h1>
        </div>
        <div class="head-control">
            <?php echo $__env->make('admin.layout.header_setting', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>
    </header>
    <div class="row top-20 padding-0">
        <div class="col-md-10">
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="<?php echo e(route('admin.dashboard')); ?>"><?php echo e(_('label.dashboard')); ?></a></li>
                <li class="breadcrumb-item active"><a href="<?php echo e(route('patient.index')); ?>"><?php echo e(__('label.patients')); ?></a></li>
                <li class="breadcrumb-item active"><a href=""><?php echo e(__('label.edit_patient')); ?></a></li>
            </ol>
        </div>
    </div>

    <div class="body-content">
        <div class="card custom-border-card mt-3">
            <h5 class="card-header"><?php echo e(__('label.edit_patient')); ?></h5>
                <div class="card-body">
                    <form class="cmxform" autocomplete="off" id="save_patient" enctype="multipart/form-data">
                                	         <?php echo csrf_field(); ?>

                        <input type="hidden" name="id" value="<?php if($data): ?><?php echo e($data->id); ?><?php endif; ?>">
                        <div class="col-md-12">
                            <div class="form-group row">
                                <div class="col-md-6">
                                    <label><?php echo e(__('label.patient_id')); ?></label>
                                        <input type="text" class="form-control" name="patient_id" value="<?php if($data): ?><?php echo e($data->patient_id); ?><?php endif; ?>">
                                </div>
                                <div class="col-md-6">
                                    <label><?php echo e(__('label.full_name')); ?></label>
                                        <input type="text" class="form-control" name="fullname" value="<?php if($data): ?><?php echo e($data->fullname); ?><?php endif; ?>">
                                </div>
                            </div>
                        </div>   

                        <div class="col-md-12">
                            <div class="form-group row">
                                <div class="col-md-6">
                                    <label><?php echo e(__('label.email')); ?></label>
                                        <input type="text" class="form-control" name="email" value="<?php if($data): ?><?php echo e($data->email); ?><?php endif; ?>">
                                </div>
                                <div class="col-md-6">
                                    <label><?php echo e(__('label.password')); ?></label>
                                        <input type="password" class="form-control" name="password" value="<?php if($data): ?><?php echo e($data->password); ?><?php endif; ?>">
                                </div>
                            </div>
                        </div> 

                        <div class="col-md-12">
                            <div class="form-group row">
                                <div class="col-md-6">
                                    <label><?php echo e(__('label.mobile_number')); ?></label>
                                        <input type="text" class="form-control" name="mobile_number" value="<?php if($data): ?><?php echo e($data->mobile_number); ?><?php endif; ?>">
                                </div>
                            </div>
                        </div>

                        <div class="col-md-12">
                            <div class="form-group row">
                                <div class="col-md-6">
                                    <label><?php echo e(__('label.instragram_url')); ?></label>
                                        <input type="text" class="form-control" name="instagram_url" value="<?php if($data): ?><?php echo e($data->instagram_url); ?><?php endif; ?>">
                                </div>
                                <div class="col-md-6">
                                    <label><?php echo e(__('label.facebook_url')); ?></label>
                                        <input type="text" class="form-control" name="facebook_url" value="<?php if($data): ?><?php echo e($data->facebook_url); ?><?php endif; ?>">
                                </div>
                            </div>
                        </div> 

                        <div class="col-md-12">
                            <div class="form-group row">
                                <div class="col-md-6">
                                    <label><?php echo e(__('label.twitter_url')); ?></label>
                                        <input type="text" class="form-control" name="twitter_url" value="<?php if($data): ?><?php echo e($data->twitter_url); ?><?php endif; ?>">
                                </div>
                                <div class="col-md-6">
                                    <label><?php echo e(__('label.bio_data')); ?></label>
                                        <input type="text" class="form-control" name="biodata" value="<?php if($data): ?><?php echo e($data->biodata); ?><?php endif; ?>">
                                </div>
                            </div>
                        </div> 

                        <div class="col-sm-12">
                            <div class="form-group">
                                <label class="mb-1"><?php echo e(__('label.image')); ?></label>
                                <input type="file" id="fileupload" onchange="readURL(this,'idLogo')" class="<?php if($data): ?><?php echo e($data->profile_img); ?><?php endif; ?>"  hidden name="profile_img" />
                                <input type="hidden" name="old_image" value="<?php if($data): ?><?php echo e($data->profile_img); ?><?php endif; ?>">
                                <label for="fileupload" class="form-control file-control">
                                    <img src="<?php echo e(asset('/assets/imgs/file-upload.png')); ?>" alt="" />
                                    <span>Select Image </span>
                                </label>
                                <div class="thumbnail-img" id="idMainLogo">
                                    <?php if($data && $data->profile_img): ?>
                                    <?php $app = (image_path('patient')).'/'.$data->profile_img ;?>
                                    <img id="idLogo" src="<?php echo e($app); ?>" />
                                    <?php endif; ?>
                                </div>
                            </div>
                        </div>

                        <div class="border-top pt-3 text-right">
                            <button class="btn btn-default mw-120" type="button" onclick="save_patient()"><?php echo e(__('label.save')); ?></button>
                            <a class="btn btn-default btn-dark mw-120" style="background: black;" type="button" href="<?php echo e(route('patient.index')); ?>"><?php echo e(__('label.cancel')); ?></a>
                            <input type="hidden" name="_method" value="PATCH">
                        </div>   
                    </form>
                </div>
        </div>
    </div>

</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('pagescript'); ?>
<script type="text/javascript">
      $(document).ready(function() {
        $('#fileupload').change(function(event) {
            if (event.target.files && event.target.files[0]) {
                var html = '<button class="close" type="button"> <span aria-hidden="true">&times;</span></button>';
                html = '<img src="" id="idLogo"/>';
                $('#idMainLogo').html(html)
                var reader = new FileReader();
                reader.onload = function() {
                    var output = document.getElementById('idLogo');
                    output.src = reader.result;
                };
                reader.readAsDataURL(event.target.files[0]);
                $(this).valid()
            }
        });
    });
    function save_patient(){
        var formData = new FormData($("#save_patient")[0]);
            $.ajax({
                type:'POST',
                url:'<?php echo e(route("patient.update",[$data->id])); ?>',
                data:formData,
                cache:false,
                contentType: false,
                processData: false,
                success: function (resp) {
                get_responce_message(resp, 'save_patient', '<?php echo e(route("patient.index")); ?>');
                },
                error: function(XMLHttpRequest, textStatus, errorThrown) {
                    $("#dvloader").hide();
                    toastr.error(errorThrown.msg,'failed');         
                }
            });
        }
</script>	

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout.page-app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u451299909/domains/divinetechs.in/public_html/demo/apps/dtcare/resources/views/admin/patient/edit.blade.php ENDPATH**/ ?>