 
   <div>
        <a href="<?php echo e(route('Setting')); ?>" class="btn head-btn" aria-haspopup="true" aria-expanded="false">
            <img src="<?php echo e(asset('/assets/imgs/setting-colored.png')); ?>">
        </a>
    </div>

    <!-- <div class="dropdown dropright">
        <a href="#" class="btn head-btn" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
            <img src="<?php echo e(asset('/assets/imgs/lang.png')); ?>">
        </a>
        <div class="dropdown-menu" aria-labelledby="dropdownMenuLink">
            <?php $__currentLoopData = language(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <a class="dropdown-item" href="<?php echo e(route('Language',$item->id)); ?>"><?php echo e($item->language); ?></a>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div> -->

    <div class="dropdown dropright">
        <a href="#" class="btn head-btn" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
            <img src="<?php echo e(asset('/assets/imgs/avatar.png')); ?>" class="avatar-img" />
        </a>
        <div class="dropdown-menu" aria-labelledby="dropdownMenuLink">
            <a class="dropdown-item" href="<?php echo e(route('Logout')); ?>">Logout</a>
        </div>

        <div class="dropdown-menu p-2 mt-2" aria-labelledby="dropdownMenuLink">
            <a class="dropdown-item" href="#">
            <br>
            </a>
            <a class="dropdown-item" href="<?php echo e(url('/')); ?>" style="color:#4E45B8;"><span><img src="<?php echo e(asset('assets/imgs/Logout-sm.png')); ?>" class="mr-2"></span><?php echo e(__('label.logout')); ?></a>
        </div>
    </div><?php /**PATH D:\xampp\htdocs\envato\app\dt_care_laravel\resources\views/admin/layout/header_setting.blade.php ENDPATH**/ ?>