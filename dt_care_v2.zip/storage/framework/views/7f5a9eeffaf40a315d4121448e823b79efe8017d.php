<?php $__env->startSection('content'); ?>
<?php echo $__env->make('admin.layout.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<div class="right-content">
    <header class="header">
        <div class="title-control">
            <h1 class="page-title"><?php echo e(__('label.specialitie')); ?></h1>
        </div>
        <div class="head-control">
            <?php echo $__env->make('admin.layout.header_setting', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>
    </header>
    <div class="row top-20 ml-3 mr-3">
        <div class="col-md-12">
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="<?php echo e(route('admin.dashboard')); ?>"><?php echo e(__('label.dashboard')); ?></a></li>
                <li class="breadcrumb-item active"><a href="<?php echo e(route('specialties.index')); ?>"><?php echo e(__('label.specialitie')); ?></a></li>
                <li class="breadcrumb-item active"><a href=""><?php echo e(__('label.edit_specialitie')); ?></a></li>
            </ol>
        </div>
     
    </div>

<div class="body-content">
    <div class="card custom-border-card mt-3">
        <h5 class="card-header"><?php echo e(__('label.edit_specialitie')); ?></h5>
        <div class="card-body">
            <form class="cmxform" autocomplete="off" id="edit_specialties" enctype="multipart/form-data">
                                	         <?php echo csrf_field(); ?>

                    <input type="hidden" name="id" value="<?php if($data): ?><?php echo e($data->id); ?><?php endif; ?>">
                   
                    <div class="form-group row">
                        <div class="col-md-6">
                            <label><?php echo e(__('label.name')); ?></label>
                            <input type="text" class="form-control" name="name" value="<?php if($data): ?><?php echo e($data->name); ?><?php endif; ?>">
                        </div>
                      
                    </div>  
                    
                    <div class="col-sm-12">
                            <div class="form-group">
                                <label class="mb-1"><?php echo e(__('label.image')); ?></label>
                                <input type="file" id="fileupload" onchange="readURL(this,'idLogo')" class="<?php if($data): ?><?php echo e($data->image); ?><?php endif; ?>"  hidden name="image" />
                                <input type="hidden" name="old_image" value="<?php if($data): ?><?php echo e($data->image); ?><?php endif; ?>">
                                <label for="fileupload" class="form-control file-control">
                                    <img src="<?php echo e(asset('/assets/imgs/file-upload.png')); ?>" alt="" />
                                    <span>Select Image </span>
                                </label>
                                <div class="thumbnail-img" id="idMainLogo">
                                    <?php if($data && $data->image): ?>
                                    <?php $app = (image_path('specialties')).'/'.$data->image ;?>
                                    <img id="idLogo" src="<?php echo e($app); ?>" />
                                    <?php endif; ?>
                                </div>
                            </div>
                        </div>
                    
    
                    <div class="border-top pt-3 text-right">
                        <button class="btn btn-default mw-120" type="button" onclick="edit_specialties()"><?php echo e(__('label.save')); ?></button>
                        <a class="btn btn-default btn-dark mw-120" style="background: black;" type="button" href="<?php echo e(route('specialties.index')); ?>"><?php echo e(__('label.cancel')); ?></a>
                        <input type="hidden" name="_method" value="PATCH">
                    </div>   
                  
                </form>
           
        </div>
    </div>
</div>

 
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('pagescript'); ?>


<script type="text/javascript">
      $(document).ready(function() {
        $('#fileupload').change(function(event) {
            if (event.target.files && event.target.files[0]) {
                var html = '<button class="close" type="button"> <span aria-hidden="true">&times;</span></button>';
                html = '<img src="" id="idLogo"/>';
                $('#idMainLogo').html(html)
                var reader = new FileReader();
                reader.onload = function() {
                    var output = document.getElementById('idLogo');
                    output.src = reader.result;
                };
                reader.readAsDataURL(event.target.files[0]);
                $(this).valid()
            }
        });
    });

        function edit_specialties(){

            var formData = new FormData($("#edit_specialties")[0]);
            $.ajax({
                type:'POST',
                url:'<?php echo e(route("specialties.update" ,[$data->id])); ?>',
                data:formData,
                cache:false,
                contentType: false,
                processData: false,
                success: function (resp) {
                get_responce_message(resp, 'edit_specialties', '<?php echo e(route("specialties.index")); ?>');
                },
                error: function(XMLHttpRequest, textStatus, errorThrown) {
                    $("#dvloader").hide();
                    toastr.error(errorThrown.msg,'failed');         
                }
            });
        }
</script>	

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout.page-app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u451299909/domains/divinetechs.in/public_html/demo/apps/dtcare/resources/views/admin/specialties/edit.blade.php ENDPATH**/ ?>