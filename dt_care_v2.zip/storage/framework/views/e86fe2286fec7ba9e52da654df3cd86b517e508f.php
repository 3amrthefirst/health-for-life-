<?php $__env->startSection('content'); ?>
<?php echo $__env->make('admin.layout.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<div class="right-content">

  <header class="header">
      <div class="title-control">
          <h1 class="page-title"><?php echo e(__('label.setting')); ?></h1>
      </div>
      <div class="head-control">
          <?php echo $__env->make('admin.layout.header_setting', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
      </div>
  </header>

  <div class="row top-20 ml-2 mr-2">
      <div class="col-md-12">
          <ol class="breadcrumb">
              <li class="breadcrumb-item"><a href="<?php echo e(route('admin.dashboard')); ?>"><?php echo e(__('label.dashboard')); ?></a></li>
              <li class="breadcrumb-item active"><a href="<?php echo e(route('Setting')); ?>"><?php echo e(__('label.setting')); ?></a></li>
          </ol>
      </div>
  </div>

  <ul class="nav nav-pills custom-tabs inline-tabs ml-3 mr-3" id="pills-tab" role="tablist">
    <li class="nav-item">
        <a class="nav-link active" id="pills-settings-tab" data-toggle="pill" href="#pills-settings" role="tab"
            aria-controls="pills-settings" aria-selected="true"><?php echo e(__('label.app_setting')); ?></a>
    </li>
    <li class="nav-item">
        <a class="nav-link" id="pills-password-tab" data-toggle="pill" href="#pills-password" role="tab"
            aria-controls="pills-password" aria-selected="false"><?php echo e(__('label.change_password')); ?></a>
    </li>
    <li class="nav-item">
        <a class="nav-link" id="pills-admob-tab" data-toggle="pill" href="#pills-admob" role="tab"
            aria-controls="pills-admob" aria-selected="false"><?php echo e(__('label.admob')); ?></a>
    </li>
    <!-- <li class="nav-item">
        <a class="nav-link" id="pills-facebook-tab" data-toggle="pill" href="#pills-facebook" role="tab"
            aria-controls="pills-facebook" aria-selected="false"><?php echo e(__('label.facebook')); ?></a>
    </li> -->
  </ul>

  <div class="tab-content mr-3 ml-3" id="pills-tabContent">
    <div class="tab-pane fade show active" id="pills-settings" role="tabpanel" aria-labelledby="pills-settings-tab">
      <div class="app-right-btn">
          <a href="<?php echo e(route('EmailSetting')); ?>" class="btn btn-default"><?php echo e(__('label.smtp')); ?></a>
      </div> 

      <div class="card custom-border-card">
        <h5 class="card-header"><?php echo e(__('label.app_configrations')); ?></h5>
        <div class="card-body">
          <div class="input-group">
            <div class="col-2">
              <label class="d-flex align-items-center ml-5"><?php echo e(__('label.api_path')); ?></label>
            </div>
            <input type="text" readonly value="<?php echo e(url('/')); ?>/api" name="api_path" class="form-control" style="background-color:matte gray;" id="api_path">
            <div class="input-group-text btn" style="background-color:matte gray;" onclick="Function_Api_path()">
              <img src="<?php echo e(asset('/assets/imgs/copy.png')); ?>" alt=""/> 
            </div>
          </div>
        </div>
      </div>

      <div class="card custom-border-card">
          <h5 class="card-header"><?php echo e(__('label.app_setting')); ?></h5>
          <div class="card-body">
            <form class="cmxform" autocomplete="off" id="save_setting" enctype="multipart/form-data">
              <?php echo csrf_field(); ?>

                                
              <div class="form-group row">
                <div class="col-md-6">
                  <label>App Name</label>
                  <input type="text" class="form-control" name="app_name" value="<?php echo e($result['app_name']); ?>">
                </div>  
                <div class="col-md-6">
                  <label><?php echo e(__('label.host_email')); ?></label>
                  <input type="text" class="form-control" name="host_email" value="<?php echo e($result['host_email']); ?>">
                </div>
              </div>

              <div class="form-group row">
                <div class="col-md-6">
                  <label><?php echo e(__('label.app_version')); ?></label>
                  <input type="text" class="form-control" name="app_version" value="<?php echo e($result['app_version']); ?>">
                </div>
                <div class="col-md-6">
                  <label><?php echo e(__('label.author')); ?></label>
                  <input type="text" class="form-control" name="author" value="<?php echo e($result['author']); ?>">
                </div>
              </div>

              <div class="form-group row">
                <div class="col-md-6">
                  <label><?php echo e(__('label.email')); ?></label>
                  <input type="text" class="form-control" name="email" value="<?php echo e($result['email']); ?>">
                </div>
                <div class="col-md-6">
                  <label><?php echo e(__('label.contact')); ?></label>
                  <input type="text" class="form-control" name="contact" value="<?php echo e($result['contact']); ?>">
                </div>
              </div>

              <div class="form-group row">
                <div class="col-md-12">
                  <label for="bio"><?php echo e(__('label.description')); ?></label>
                  <textarea type="text" class="form-control" name="app_description" rows="4" id="app_desripation"><?php echo e($result['app_description']); ?> </textarea>
                </div>
              </div>

              <div class="form-group row">
                <div class="col-md-12">
                  <label for="bio"><?php echo e(__('label.privcy_policy')); ?></label>
                  <textarea type="text" class="form-control" name="privacy_policy" rows="4" id="privacy_policy"><?php echo e($result['privacy_policy']); ?> </textarea>
                </div>
              </div>

              <div class="form-group row">
                <div class="col-md-6">
                  <label for="input-2"><?php echo e(__('label.app_image')); ?></label>
                  <div class="custom-file">
                      <input type="file" name="app_logo"  class="custom-file-input" id="fileupload">
                      <input type="hidden" name="old_image" value="<?php if($result): ?><?php echo e($result['app_logo']); ?><?php endif; ?>">
                      <label class="custom-file-label" for="customFileLangHTML" data-browse="Bestand kiezen">Select Image</label>
                  </div>
                  <p class="noteMsg">Note: Image Size must be lessthan 2MB.Image Height and Width Maximum - 100x200</p>
                </div>
                <div class="col-md-6">
                  <label><?php echo e(__('label.website')); ?></label>
                  <input type="text" class="form-control" name="website" value="<?php echo e($result['website']); ?>">
                </div>
              </div>
              <div class="col-md-12 mb-2">
                  <?php $app = (image_path('setting')).'/'.$result['app_logo'] ; ?>
                  <img id="preview-image-before-upload" height="150" width="150" alt="preview image" src="<?php echo e($app); ?>">
              </div>

              <div class="border-top pt-3 text-right">
                  <button class="btn btn-default mw-120" type="button" onclick="save_setting()"><?php echo e(__('label.save')); ?></button>
                  <a class="btn btn-default btn-dark mw-120" style="background: black;" type="button" href="<?php echo e(route('Setting')); ?>"><?php echo e(__('label.cancel')); ?></a>
              </div>
            </form>
          </div>
      </div>
      
      <!-- <div class="card custom-border-card">
        <h5 class="card-header"><?php echo e(__('label.currency')); ?></h5>
        <div class="card-body">
          <form class="cmxform" autocomplete="off"  action="<?php echo e(route('CurrencySave')); ?>" method="post" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>

            <div class="form-group">
              <label><?php echo e(__('label.set_currency')); ?></label>
              <select name="currency" class="form-control">
                <option>
                  Select Currency
                </option>
            
                <?php $__currentLoopData = $currency; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($row->id); ?>" <?php echo e(( $row->status == 1) ? 'selected' : ''); ?>>
                  (<?php echo e($row->symbol); ?>)<?php echo e($row->name); ?>

                </option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                
              </select>
            </div>
            <div class="text-right pt-3">
              <button type="submit" class="btn btn-default mw-120"><?php echo e(__('label.save')); ?></button>
            </div>
          </form>
        </div>
      </div> -->
    </div>

    <div class="tab-pane fade" id="pills-password" role="tabpanel" aria-labelledby="pills-Premium-tab">
        <div class="card custom-border-card mt-3">
            <h5 class="card-header"><?php echo e(__('label.change_password')); ?></h5>
            <div class="card-body">
                <form class="cmxform" autocomplete="off" id="save_update_password" enctype="multipart/form-data">
                <input type="hidden" name="id" value="1">
                <?php echo csrf_field(); ?>

                    <div class="form-group">
                        <label><?php echo e(__('label.old_password')); ?></label>
                        <input type="password" name="password" id="password" class="form-control"
                            placeholder="Enter New Password">
                    </div>
                    
                    <div class="form-group">
                        <label><?php echo e(__('label.new_password')); ?></label>
                        <input type="password" class="form-control" id="new_password" name="new_password"
                            placeholder="Enter confirm  Password">
                    </div>
                    
                    <div class="form-group">
                        <button type="button" class="btn btn-default mw-120" onclick="save_update_password()"><?php echo e(__('label.save')); ?></button>
                        <a class="btn btn-default btn-dark mw-120" style="background: black;" type="button" href="<?php echo e(route('Setting')); ?>"><?php echo e(__('label.cancel')); ?></a>
                    </div>
                  </form>
            </div>
        </div>
    </div>

    <div class="tab-pane fade" id="pills-admob" role="tabpanel" aria-labelledby="pills-admob-tab">
      <div class="card custom-border-card mt-3">
        <h5 class="card-header"><?php echo e(__('label.android_settings')); ?></h5>
      
        <div class="card-body">
        <form class="cmxform" autocomplete="off" id="save_update_admob" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>

            <div class="row">
              <div class="col-12 col-sm-6 col-md-4">
                <div class="form-group">
                  <label><?php echo e(__('label.banner_add')); ?></label>
                  
                  <div class="radio-group">
                    <div class="custom-control custom-radio">
                      <input type="radio" id="banner_ad" name="Banner_Ad" <?php echo e(($result['Banner_Ad']=='yes')? "checked" : ""); ?> value="yes" class="custom-control-input" >
                      <label class="custom-control-label" for="banner_ad"><?php echo e(__('label.yes')); ?></label>
                    </div>
                    <div class="custom-control custom-radio">
                      <input type="radio" id="banner_ad1" name="Banner_Ad" <?php echo e(($result['Banner_Ad']=='no')? "checked" : ""); ?> value="yes" class="custom-control-input">
                      <label class="custom-control-label" for="banner_ad1"><?php echo e(__('label.no')); ?></label>
                    </div>
                  </div>
                </div>
              </div>
              <div class="col-12 col-sm-6 col-md-4">
                <div class="form-group">
                  <label><?php echo e(__('label.Interstital_Ad')); ?></label>
                  <div class="radio-group">
                    <div class="custom-control custom-radio">
                      <input type="radio" id="interstial_ad" name="Interstital_Ad" <?php echo e(($result['Interstital_Ad']=='yes')? "checked" : ""); ?> value="yes" class="custom-control-input"  >
                      <label class="custom-control-label" for="interstial_ad"><?php echo e(__('label.yes')); ?></label>
                    </div>
                    <div class="custom-control custom-radio">
                      <input type="radio" id="interstial_ad1" name="Interstital_Ad" <?php echo e(($result['Interstital_Ad']=='no')? "checked" : ""); ?> value="yes" class="custom-control-input" >
                      <label class="custom-control-label" for="interstial_ad1"><?php echo e(__('label.no')); ?></label>
                    </div>
                  </div>
                </div>
              </div>
              <div class="col-12 col-sm-6 col-md-4">
                <div class="form-group">
                  <label><?php echo e(__('label.Reward_Ad')); ?></label>
                  <div class="radio-group">
                    <div class="custom-control custom-radio">
                      <input type="radio" id="custom_ad" name="Reward_Ad" <?php echo e(($result['Reward_Ad']=='yes')? "checked" : ""); ?> value="yes"  class="custom-control-input"   >
                      <label class="custom-control-label" for="custom_ad"><?php echo e(__('label.yes')); ?></label>
                    </div>
                    <div class="custom-control custom-radio">
                      <input type="radio" id="custom_ad1" name="Reward_Ad" <?php echo e(($result['Reward_Ad']=='no')? "checked" : ""); ?> value="yes"  class="custom-control-input">
                      <label class="custom-control-label" for="custom_ad1"><?php echo e(__('label.no')); ?></label>
                    </div>
                  </div>
                </div>
              </div>
              <div class="col-12 col-sm-6 col-md-4">
                <div class="form-group">
                  <label><?php echo e(__('label.Banner_Ad_ID')); ?></label>
                  <input type="text" class="form-control" name="Banner_Ad_ID" value="<?php echo e($result['Banner_Ad_ID']); ?>"  placeholder="Enter Reward Ad ID">
                </div>
              </div>
              <div class="col-12 col-sm-6 col-md-4">
                <div class="form-group">
                  <label><?php echo e(__('label.Interstital_Ad_ID')); ?></label>
                  <input type="text" class="form-control" name="Interstital_Ad_ID" value="<?php echo e($result['Interstital_Ad_ID']); ?>"  placeholder="Enter Interstital Ad ID">
                </div>
                <div class="form-group">
                  <label><?php echo e(__('label.Interstital_Ad_Click')); ?></label>
                  <input type="text" class="form-control" name="Interstita_Ad_Click" value="<?php echo e($result['Interstita_Ad_Click']); ?>"  placeholder="Enter Reward Ad Click">
                </div>
              </div>
              <div class="col-12 col-sm-6 col-md-4">
                <div class="form-group">
                  <label><?php echo e(__('label.Reward_Ad_ID')); ?></label>
                  <input type="text" class="form-control" name="Reward_Ad_ID" value="<?php echo e($result['Reward_Ad_ID']); ?>"  placeholder="Enter Banner Ad ID">
                </div>
                <div class="form-group">
                  <label><?php echo e(__('label.Reward_Ad_Click')); ?></label>
                  <input type="text" class="form-control" name="Reward_Ad_Click" value="<?php echo e($result['Reward_Ad_Click']); ?>"  placeholder="Enter Interstital Ad Click">
                </div>
                
              </div>
              
              
            </div>
            <div class="text-right pt-3">
            <button type="button" class="btn btn-default mw-120" onclick="save_update_admob()"><?php echo e(__('label.save')); ?></button>
            </div>
          </form>
        </div>
      </div>

      <div class="card custom-border-card mt-3">
        <h5 class="card-header"><?php echo e(__('label.iso_setting')); ?></h5>
      
        <div class="card-body">
        <form class="cmxform" autocomplete="off" id="save_update_iso" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>

            <div class="row">
              <div class="col-12 col-sm-6 col-md-4">
                <div class="form-group">
                  <label><?php echo e(__('label.banner_add')); ?></label>
                  
                  <div class="radio-group">
                    <div class="custom-control custom-radio">
                      <input type="radio" id="banner_ad_ios" name="Banner_Ad_ios" <?php echo e(($result['Banner_Ad_ios']=='yes')? "checked" : ""); ?> value="yes" class="custom-control-input" >
                      <label class="custom-control-label" for="banner_ad_ios"><?php echo e(__('label.yes')); ?></label>
                    </div>
                    <div class="custom-control custom-radio">
                      <input type="radio" id="banner_ad1_ios" name="Banner_Ad_ios" <?php echo e(($result['Banner_Ad_ios']=='no')? "checked" : ""); ?> value="yes" class="custom-control-input">
                      <label class="custom-control-label" for="banner_ad1_ios"><?php echo e(__('label.no')); ?></label>
                    </div>
                  </div>
                </div>
              </div>
              <div class="col-12 col-sm-6 col-md-4">
                <div class="form-group">
                  <label><?php echo e(__('label.Interstital_Ad')); ?></label>
                  <div class="radio-group">
                    <div class="custom-control custom-radio">
                      <input type="radio" id="interstial_ad_ios" name="Interstital_Ad_ios" <?php echo e(($result['Interstital_Ad_ios']=='yes')? "checked" : ""); ?> value="yes" class="custom-control-input"   >
                      <label class="custom-control-label" for="interstial_ad_ios"><?php echo e(__('label.yes')); ?></label>
                    </div>
                    <div class="custom-control custom-radio">
                      <input type="radio" id="interstial_ad1_ios" name="Interstital_Ad_ios" <?php echo e(($result['Interstital_Ad_ios']=='no')? "checked" : ""); ?> value="yes" class="custom-control-input" >
                      <label class="custom-control-label" for="interstial_ad1_ios"><?php echo e(__('label.no')); ?></label>
                    </div>
                  </div>
                </div>
              </div>
              <div class="col-12 col-sm-6 col-md-4">
                <div class="form-group">
                  <label><?php echo e(__('label.Reward')); ?></label>
                  <div class="radio-group">
                    <div class="custom-control custom-radio">
                    <input type="radio" id="custom_ad_ios" name="Reward_Ad_ios" <?php echo e(($result['Reward_Ad_ios']=='yes')? "checked" : ""); ?> value="no" class="custom-control-input" >
                      <label class="custom-control-label" for="custom_ad_ios"><?php echo e(__('label.yes')); ?></label>
                    </div>
                    <div class="custom-control custom-radio">
                      <input type="radio" id="custom_ad1_ios" name="Reward_Ad_ios" <?php echo e(($result['Reward_Ad_ios']=='no')? "checked" : ""); ?> value="no" class="custom-control-input" >
                      <label class="custom-control-label" for="custom_ad1_ios"><?php echo e(__('label.no')); ?></label>
                    </div>
                  </div>
                </div>
              </div>
              <div class="col-12 col-sm-6 col-md-4">
                <div class="form-group">
                  <label><?php echo e(__('label.Banner_Ad_ID')); ?></label>
                  <input type="text" class="form-control" name="Banner_Ad_ID_ios" value="<?php echo e($result['Banner_Ad_ID_ios']); ?>"  placeholder="Enter Reward Ad ID">
                </div>
              </div>
              <div class="col-12 col-sm-6 col-md-4">
                <div class="form-group">
                  <label><?php echo e(__('label.Interstital_Ad_ID')); ?></label>
                  <input type="text" class="form-control" name="Interstital_Ad_ID_ios" value="<?php echo e($result['Interstital_Ad_ID_ios']); ?>"  placeholder="Enter Interstital Ad ID">
                </div>
                <div class="form-group">
                  <label><?php echo e(__('label.Interstital_Ad_Click')); ?></label>
                  <input type="text" class="form-control" name="Interstita_Ad_Click_ios" value="<?php echo e($result['Interstita_Ad_Click_ios']); ?>"  placeholder="Enter Reward Ad Click">
                </div>
              </div>
              <div class="col-12 col-sm-6 col-md-4">
                <div class="form-group">
                  <label><?php echo e(__('label.Reward_Ad_ID')); ?></label>
                  <input type="text" class="form-control" name="Reward_Ad_id_iso" value="<?php echo e($result['Reward_Ad_id_iso']); ?>"  placeholder="Enter Banner Ad ID">
                </div>
                <div class="form-group">
                  <label><?php echo e(__('label.Reward_Ad_Click')); ?></label>
                  <input type="text" class="form-control" name="Reward_Ad_click_iso" value="<?php echo e($result['Reward_Ad_click_iso']); ?>"  placeholder="Enter Interstital Ad Click">
                </div>
                
              </div>
              
              
            </div>
            <div class="text-right pt-3">
            <button type="button" class="btn btn-default mw-120" onclick="save_update_iso()"><?php echo e(__('label.save')); ?></button>
            </div>
          </form>
        </div>
      </div>
      
    </div>

    <!-- <div class="tab-pane fade" id="pills-facebook" role="tabpanel" aria-labelledby="pills-facebook-tab">
      <div class="card custom-border-card mt-3">
        <h5 class="card-header"><?php echo e(__('label.android_settings')); ?></h5>
      
        <div class="card-body">
        <form class="cmxform" autocomplete="off" id="save_update_facebook_admob" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>

            <div class="row">
              <div class="col-12 col-sm-6 col-md-4">
                <div class="form-group">
                  <label><?php echo e(__('label.rewar_video_status')); ?></label>
                    <div class="radio-group">
                      <div class="custom-control custom-radio">
                        <input type="radio" id="fb_rewardvideo_status" name="fb_rewardvideo_status" <?php echo e(($result['fb_rewardvideo_status']=='yes')? "checked" : ""); ?> value="yes" class="custom-control-input"   >
                        <label class="custom-control-label" for="fb_rewardvideo_status"><?php echo e(__('label.yes')); ?></label>
                      </div>
                      <div class="custom-control custom-radio">
                        <input type="radio" id="fb_rewardvideo_status1" name="fb_rewardvideo_status" <?php echo e(($result['fb_rewardvideo_status']=='no')? "checked" : ""); ?> value="yes" class="custom-control-input"   >
                        <label class="custom-control-label" for="fb_rewardvideo_status1"><?php echo e(__('label.no')); ?></label>
                      </div>
                    </div>
                </div>
              </div>
              
              <div class="col-12 col-sm-6 col-md-4">
                <div class="form-group">
                  <label><?php echo e(__('label.Native_Status')); ?></label>
                  <div class="radio-group">
                    <div class="custom-control custom-radio">
                      <input type="radio" id="fb_native_status" name="fb_native_status" <?php echo e(($result['fb_native_status']=='yes')? "checked" : ""); ?> value="yes" class="custom-control-input"   >
                      <label class="custom-control-label" for="fb_native_status"><?php echo e(__('label.yes')); ?></label>
                    </div>
                    <div class="custom-control custom-radio">
                      <input type="radio" id="fb_native_status1" name="fb_native_status" <?php echo e(($result['fb_native_status']=='no')? "checked" : ""); ?> value="yes" class="custom-control-input" >
                      <label class="custom-control-label" for="fb_native_status1"><?php echo e(__('label.no')); ?></label>
                    </div>
                  </div>
                </div>
              </div>
              
              <div class="col-12 col-sm-6 col-md-4">
                <div class="form-group">
                  <label><?php echo e(__('label.Banner_Status')); ?></label>
                  <div class="radio-group">
                    <div class="custom-control custom-radio">
                    <input type="radio" id="fb_banner_status" name="fb_banner_status" <?php echo e(($result['fb_banner_status']=='yes')? "checked" : ""); ?> value="yes" class="custom-control-input"   >
                      <label class="custom-control-label" for="fb_banner_status"><?php echo e(__('label.yes')); ?></label>
                    </div>
                    <div class="custom-control custom-radio">
                    <input type="radio" id="fb_banner_status1" name="fb_banner_status" <?php echo e(($result['fb_banner_status']=='no')? "checked" : ""); ?> value="yes" class="custom-control-input" >
                      <label class="custom-control-label" for="fb_banner_status1"><?php echo e(__('label.no')); ?></label>
                    </div>
                  </div>
                </div>
              </div>
              
              <div class="col-12 col-sm-6 col-md-4">
                <div class="form-group">
                  <label><?php echo e(__('label.Rewarvideo_Id')); ?></label>
                  <input type="text" class="form-control" name="fb_rewardvideo_id" value="<?php echo e($result['fb_rewardvideo_id']); ?>"  placeholder="Enter Reward Ad ID">
                </div>
                <div class="form-group">
                  <label><?php echo e(__('label.Interstiatial_Status')); ?></label>
                    <div class="radio-group">
                      <div class="custom-control custom-radio">
                        <input type="radio" id="fb_interstiatial_status" name="fb_interstiatial_status" <?php echo e(($result['fb_interstiatial_status']=='yes')? "checked" : ""); ?> value="yes" class="custom-control-input"   >
                        <label class="custom-control-label" for="fb_interstiatial_status"><?php echo e(__('label.yes')); ?></label>
                      </div>
                      <div class="custom-control custom-radio">
                        <input type="radio" id="fb_interstiatial_status1" name="fb_interstiatial_status" <?php echo e(($result['fb_interstiatial_status']=='no')? "checked" : ""); ?> value="yes" class="custom-control-input"   >
                        <label class="custom-control-label" for="fb_interstiatial_status1"><?php echo e(__('label.no')); ?></label>
                      </div>
                    </div>
                </div>
                <div class="form-group">
                  <label><?php echo e(__('label.Interstiatial_Id')); ?></label>
                  <input type="text" class="form-control" name="fb_interstiatial_id" value="<?php echo e($result['fb_interstiatial_id']); ?>"  placeholder="Enter Interstital Ad ID">
                </div>
              </div>
              
              <div class="col-12 col-sm-6 col-md-4">
                <div class="form-group">
                  <label><?php echo e(__('label.Native_Id')); ?></label>
                  <input type="text" class="form-control" name="fb_native_id" value="<?php echo e($result['fb_native_id']); ?>"  placeholder="Enter Interstital Ad ID">
                </div>
                <div class="form-group">
                  <label><?php echo e(__('label.NativeFull_Status')); ?></label>
                  <div class="radio-group">
                    <div class="custom-control custom-radio">
                      <input type="radio" id="fb_native_full_status" name="fb_native_full_status" <?php echo e(($result['fb_native_full_status']=='yes')? "checked" : ""); ?> value="yes"  class="custom-control-input"   >
                      <label class="custom-control-label" for="fb_native_full_status"><?php echo e(__('label.yes')); ?></label>
                    </div>
                    <div class="custom-control custom-radio">
                      <input type="radio" id="fb_native_full_status1" name="fb_native_full_status" <?php echo e(($result['fb_native_full_status']=='no')? "checked" : ""); ?> value="yes"  class="custom-control-input" >
                      <label class="custom-control-label" for="fb_native_full_status1"><?php echo e(__('label.no')); ?></label>
                    </div>
                  </div>
                </div>
                <div class="form-group">
                  <label><?php echo e(__('label.Native_FUll_id')); ?></label>
                  <input type="text" class="form-control" name="fb_native_full_id" value="<?php echo e($result['fb_native_full_id']); ?>"  placeholder="Enter Reward Ad Click">
                </div>
              </div>

              <div class="col-12 col-sm-6 col-md-4">
                <div class="form-group">
                  <label><?php echo e(__('label.Banner_ID')); ?></label>
                  <input type="text" class="form-control" name="fb_banner_id" value="<?php echo e($result['fb_banner_id']); ?>"  placeholder="Enter Banner Ad ID">
                </div>
              </div>

            </div>
            <div class="border-top pt-3 text-right">
              <button type="button" class="btn btn-default mw-120" onclick="save_update_facebook_admob()"><?php echo e(__('label.save')); ?></button>
            </div>
          </form>
        </div>
      </div>
    
        <div class="card custom-border-card mt-3">
        <h5 class="card-header"><?php echo e(__('label.iso_setting')); ?></h5>
      
        <div class="card-body">
        <form class="cmxform" autocomplete="off" id="save_update_facebook_iso" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>

            <div class="row">
              <div class="col-12 col-sm-6 col-md-4">
                <div class="form-group">
                  <label><?php echo e(__('label.rewar_video_status')); ?></label>
                    <div class="radio-group">
                      <div class="custom-control custom-radio">
                        <input type="radio" id="fb_rewardvideo_status_iso" name="fb_rewardvideo_status_iso" <?php echo e(($result['fb_rewardvideo_status_iso']=='yes')? "checked" : ""); ?> value="yes" class="custom-control-input"   >
                        <label class="custom-control-label" for="fb_rewardvideo_status_iso">Yes</label>
                      </div>
                      <div class="custom-control custom-radio">
                        <input type="radio" id="fb_rewardvideo_status_iso1" name="fb_rewardvideo_status_iso" <?php echo e(($result['fb_rewardvideo_status_iso']=='no')? "checked" : ""); ?> value="yes" class="custom-control-input"   >
                        <label class="custom-control-label" for="fb_rewardvideo_status_iso1">No</label>
                      </div>
                    </div>
                </div>
              </div>
              
              <div class="col-12 col-sm-6 col-md-4">
                <div class="form-group">
                  <label><?php echo e(__('label.Native_Status')); ?></label>
                  <div class="radio-group">
                    <div class="custom-control custom-radio">
                      <input type="radio" id="fb_native_status_iso" name="fb_native_status_iso" <?php echo e(($result['fb_native_status_iso']=='yes')? "checked" : ""); ?> value="yes" class="custom-control-input"   >
                      <label class="custom-control-label" for="fb_native_status_iso">Yes</label>
                    </div>
                    <div class="custom-control custom-radio">
                      <input type="radio" id="fb_native_status_iso1" name="fb_native_status_iso" <?php echo e(($result['fb_native_status_iso']=='no')? "checked" : ""); ?> value="yes" class="custom-control-input" >
                      <label class="custom-control-label" for="fb_native_status_iso1">No</label>
                    </div>
                  </div>
                </div>
              </div>
              
              <div class="col-12 col-sm-6 col-md-4">
                <div class="form-group">
                  <label><?php echo e(__('label.Banner_Status')); ?></label>
                  <div class="radio-group">
                    <div class="custom-control custom-radio">
                    <input type="radio" id="fb_banner_status_iso" name="fb_banner_status_iso" <?php echo e(($result['fb_banner_status_iso']=='yes')? "checked" : ""); ?> value="yes" class="custom-control-input"   >
                      <label class="custom-control-label" for="fb_banner_status">Yes</label>
                    </div>
                    <div class="custom-control custom-radio">
                    <input type="radio" id="fb_banner_status_iso1" name="fb_banner_status_iso" <?php echo e(($result['fb_banner_status_iso']=='no')? "checked" : ""); ?> value="yes" class="custom-control-input" >
                      <label class="custom-control-label" for="fb_banner_status_iso1">No</label>
                    </div>
                  </div>
                </div>
              </div>
              
              <div class="col-12 col-sm-6 col-md-4">
                <div class="form-group">
                  <label><?php echo e(__('label.Rewarvideo_Id')); ?></label>
                  <input type="text" class="form-control" name="fb_rewardvideo_id_iso" value="<?php echo e($result['fb_rewardvideo_id_iso']); ?>"  placeholder="Enter Reward Ad ID">
                </div>

                <div class="form-group">
                  <label><?php echo e(__('label.Interstiatial_Status')); ?></label>
                    <div class="radio-group">
                      <div class="custom-control custom-radio">
                        <input type="radio" id="fb_interstiatial_status_iso" name="fb_interstiatial_status_iso" <?php echo e(($result['fb_interstiatial_status_iso']=='yes')? "checked" : ""); ?> value="yes" class="custom-control-input"   >
                        <label class="custom-control-label" for="fb_interstiatial_status_iso">Yes</label>
                      </div>
                      <div class="custom-control custom-radio">
                        <input type="radio" id="fb_interstiatial_status_iso1" name="fb_interstiatial_status_iso" <?php echo e(($result['fb_interstiatial_status_iso']=='no')? "checked" : ""); ?> value="yes" class="custom-control-input"   >
                        <label class="custom-control-label" for="fb_interstiatial_status_iso1">No</label>
                      </div>
                    </div>
                </div>
                <div class="form-group">
                  <label><?php echo e(__('label.Interstiatial_Id')); ?></label>
                  <input type="text" class="form-control" name="fb_interstiatial_id_iso" value="<?php echo e($result['fb_interstiatial_id_iso']); ?>"  placeholder="Enter Interstital Ad ID">
                </div>
              </div>
              
              <div class="col-12 col-sm-6 col-md-4">
                <div class="form-group">
                  <label><?php echo e(__('label.Native_Id')); ?></label>
                  <input type="text" class="form-control" name="fb_native_id_iso" value="<?php echo e($result['fb_native_id_iso']); ?>"  placeholder="Enter Interstital Ad ID">
                </div>

                <div class="form-group">
                  <label><?php echo e(__('label.NativeFull_Status')); ?></label>
                  <div class="radio-group">
                    <div class="custom-control custom-radio">
                      <input type="radio" id="fb_native_full_status_iso" name="fb_native_full_status_iso" <?php echo e(($result['fb_native_full_status_iso']=='yes')? "checked" : ""); ?> value="yes"  class="custom-control-input"   >
                      <label class="custom-control-label" for="fb_native_full_status">Yes</label>
                    </div>
                    <div class="custom-control custom-radio">
                      <input type="radio" id="fb_native_full_status_iso1" name="fb_native_full_status_iso" <?php echo e(($result['fb_native_full_status_iso']=='no')? "checked" : ""); ?> value="yes"  class="custom-control-input" >
                      <label class="custom-control-label" for="fb_native_full_status_iso1">No</label>
                    </div>
                  </div>
                </div>

                <div class="form-group">
                  <label><?php echo e(__('label.Native_FUll_id')); ?></label>
                  <input type="text" class="form-control" name="fb_native_full_id_iso" value="<?php echo e($result['fb_native_full_id_iso']); ?>"  placeholder="Enter Reward Ad Click">
                </div>
              </div>

              <div class="col-12 col-sm-6 col-md-4">
                <div class="form-group">
                  <label><?php echo e(__('label.Banner_ID')); ?></label>
                  <input type="text" class="form-control" name="fb_banner_id_iso" value="<?php echo e($result['fb_banner_id_iso']); ?>"  placeholder="Enter Banner Ad ID">
                </div>
              </div>
            </div>
            <div class="border-top pt-3 text-right">
            <button type="button" class="btn btn-default mw-120" onclick="save_update_facebook_iso()"><?php echo e(__('label.save')); ?></button>
            </div>
          </form>
        </div>
      </div>

    </div>   -->
  </div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('pagescript'); ?>
    <script type="text/javascript">
        
        function Function_Api_path(){
            var copyText =document.getElementById("api_path");
            copyText.select();
            copyText.setSelectionRange(0, 99999);
            document.execCommand('copy');
            alert("Copied The API Path: " + copyText.value);
        }
    
        $(document).ready(function (e) {
            $('#fileupload').change(function(){
            let reader = new FileReader();
            reader.onload = (e) => { 
                $('#preview-image-before-upload').attr('src', e.target.result); 
            }
            reader.readAsDataURL(this.files[0]); 
            });
        });
    
        function save_setting(){
            var formData = new FormData($("#save_setting")[0]);
            $.ajax({
                type:'POST',
                url:'<?php echo e(route("SettingSave")); ?>',
                data:formData,
                cache:false,
                contentType: false,
                processData: false,
                success: function (resp) {
                    
                get_responce_message(resp, 'save_setting', '<?php echo e(route("Setting")); ?>');
                },
                error: function(XMLHttpRequest, textStatus, errorThrown) {
                    $("#dvloader").hide();
                    toastr.error(errorThrown.msg,'failed');         
                }
            });
        }

        function save_update_password(){
            var formData = new FormData($("#save_update_password")[0]);
            $.ajax({
                type:'POST',
                url:'<?php echo e(route("PwdSave")); ?>',
                data:formData,
                cache:false,
                contentType: false,
                processData: false,
                success: function (resp) {
                get_responce_message(resp, 'save_update_password', '<?php echo e(route("Setting")); ?>');
                },
                error: function(XMLHttpRequest, textStatus, errorThrown) {
                    $("#dvloader").hide();
                    toastr.error(errorThrown.msg,'failed');         
                }
            });
        }

        function save_update_admob(){
            var formData = new FormData($("#save_update_admob")[0]);
            $.ajax({
                type:'POST',
                url:'<?php echo e(route("AdmobUpdate")); ?>',
                data:formData,
                cache:false,
                contentType: false,
                processData: false,
                success: function (resp) {
                get_responce_message(resp, 'save_update_admob', '<?php echo e(route("Setting")); ?>');
                },
                error: function(XMLHttpRequest, textStatus, errorThrown) {
                    $("#dvloader").hide();
                    toastr.error(errorThrown.msg,'failed');         
                }
            });
        }

        function save_update_iso(){
            var formData = new FormData($("#save_update_iso")[0]);
            $.ajax({
                type:'POST',
                url:'<?php echo e(route("IsoUpdate")); ?>',
                data:formData,
                cache:false,
                contentType: false,
                processData: false,
                success: function (resp) {
                get_responce_message(resp, 'save_update_iso', '<?php echo e(route("Setting")); ?>');
                },
                error: function(XMLHttpRequest, textStatus, errorThrown) {
                    $("#dvloader").hide();
                    toastr.error(errorThrown.msg,'failed');         
                }
            });
        }

        function save_update_facebook_admob(){
            var formData = new FormData($("#save_update_facebook_admob")[0]);
            $.ajax({
                type:'POST',
                url:'<?php echo e(route("facebookupdate")); ?>',
                data:formData,
                cache:false,
                contentType: false,
                processData: false,
                success: function (resp) {
                get_responce_message(resp, 'save_update_facebook_admob', '<?php echo e(route("Setting")); ?>');
                },
                error: function(XMLHttpRequest, textStatus, errorThrown) {
                    $("#dvloader").hide();
                    toastr.error(errorThrown.msg,'failed');         
                }
            });
        }

        function save_update_facebook_iso(){
            var formData = new FormData($("#save_update_facebook_iso")[0]);
            $.ajax({
                type:'POST',
                url:'<?php echo e(route("facebookiso")); ?>',
                data:formData,
                cache:false,
                contentType: false,
                processData: false,
                success: function (resp) {
                get_responce_message(resp, 'save_update_facebook_iso', '<?php echo e(route("Setting")); ?>');
                },
                error: function(XMLHttpRequest, textStatus, errorThrown) {
                    $("#dvloader").hide();
                    toastr.error(errorThrown.msg,'failed');         
                }
            });
        }
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout.page-app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\envato\app\dt_care_laravel\resources\views/admin/setting/index.blade.php ENDPATH**/ ?>