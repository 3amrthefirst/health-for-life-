<?php $__env->startSection('content'); ?>
<?php echo $__env->make('admin.layout.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<div class="right-content">
    <header class="header">
        <div class="title-control">
            <h1 class="page-title"><?php echo e(__('label.specialitie')); ?></h1>
        </div>
        <div class="head-control">
            <?php echo $__env->make('admin.layout.header_setting', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>
    </header>

    <div class="row top-20 ml-2">
        <div class="col-md-10">
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="<?php echo e(route('admin.dashboard')); ?>"><?php echo e(__('label.dashboard')); ?></a></li>
                <li class="breadcrumb-item active"><a href="<?php echo e(route('specialties.index')); ?>"><?php echo e(__('label.specialitie')); ?></a></li>
            </ol>
        </div>
        <div class="col-md-2">
            <div class="mb-3 pb-3">
                <a href="<?php echo e(route('specialties.create')); ?>" class="btn btn-default mw-120"><?php echo e(__('label.add_specialitie')); ?></a>
            </div>
        </div>
     
    </div>

    <div class="col-md-12 top-20 padding-0">
            <div class="col-md-12">
                <div class="panel">
                    <div class="panel-body">
                        <div class="responsive-table">
                            <table class="table table-striped table-bordered text-center" id="specialties">
                                <thead style="background: #F9FAFF;">
                                    <tr>
                                        <th><?php echo e(__('label.id')); ?></th>
                                        <th><?php echo e(__('label.icon')); ?></th>
                                        <th><?php echo e(__('label.name')); ?></th>
                                        <th><?php echo e(__('label.action')); ?></th>
                                    </tr>
                                </thead>
                                <tbody>

                                </tbody>
                            </table>
                        </div>
                    </div> 
                </div>
	        </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('pagescript'); ?>
    <script type="text/javascript">
        $(function () {
            var table = $('#specialties').DataTable({
                "responsive": true,
                "autoWidth": false,
                lengthMenu: [ [10, 25, 50, -1], [10, 25, 50, 'All'] ],
                processing: true,
                serverSide: true,
                language: {
                    paginate: {
                    previous: " <img src='<?php echo e(url('assets/imgs/left-arrow.png')); ?>'>",
                    next: " <img src='<?php echo e(url('assets/imgs/left-arrow.png')); ?>' style='transform:rotate(180deg)'>"
                    }
                },
                order: [[0, "DESC"]],
                ajax:"<?php echo e(route('specialties.store')); ?>",
                columns: [
                
                {data: 'id',name: 'id'},
                { data: 'image', name: 'image', orderable: false, searchable: false,
                    "render": function (data, type, full, meta) {
                        if(data && data != null){
                        return "<img src='<?php echo e(image_path('specialties')); ?>/" + data + "' height=50 Width=50>";
                        } else {
                        return "<img src='<?php echo e(asset('assets/imgs/1.png')); ?>' height='50' width=50>";
                        }
                    },
                },
                {data: 'name', name: 'name'},
                {data: 'Action' ,name: 'Action', orderable: false, searchable: false},
                
                ]
            });
        });
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout.page-app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\envato\app\dt_care_laravel\resources\views/admin/specialties/index.blade.php ENDPATH**/ ?>